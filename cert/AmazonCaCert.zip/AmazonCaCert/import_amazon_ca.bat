@echo off
setlocal

rem === Percorso di destinazione del certificato ===
set CERT_FILE=AmazonCaCert/AmazonRootCA1.cer
rem === Importazione nel keystore ===
echo Importo il certificato nel keystore Java...

"C:\NemesiX\java\windows\jre7\bin\keytool.exe" -importcert ^
  -alias amazon-root ^
  -file "%CERT_FILE%" ^
  -keystore "C:\NemesiX\java\windows\jre7\lib\security\cacerts" ^
  -storepass changeit ^
  -noprompt

echo Operazione completata.
pause
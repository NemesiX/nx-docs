@ECHO OFF
REM         _             _           _   _         _           _           _     _      _      
REM        /\ \     _    /\ \        /\_\/\_\ _    /\ \        / /\        /\ \ /_/\    /\ \    
REM       /  \ \   /\_\ /  \ \      / / / / //\_\ /  \ \      / /  \       \ \ \\ \ \   \ \_\   
REM      / /\ \ \_/ / // /\ \ \    /\ \/ \ \/ / // /\ \ \    / / /\ \__    /\ \_\\ \ \__/ / /   
REM     / / /\ \___/ // / /\ \_\  /  \____\__/ // / /\ \_\  / / /\ \___\  / /\/_/ \ \__ \/_/    
REM    / / /  \/____// /_/_ \/_/ / /\/________// /_/_ \/_/  \ \ \ \/___/ / / /     \/_/\__/\    
REM    / / /    / / // /____/\   / / /\/_// / // /____/\      \ \ \      / / /       _/\/__\ \   
REM   / / /    / / // /\____\/  / / /    / / // /\____\/  _    \ \ \    / / /       / _/_/\ \ \  
REM  / / /    / / // / /______ / / /    / / // / /______ /_/\__/ / /___/ / /__     / / /   \ \ \ 
REM / / /    / / // / /_______\\/_/    / / // / /_______\\ \/___/ //\__\/_/___\   / / /    /_/ / 
REM \/_/     \/_/ \/__________/        \/_/ \/__________/ \_____\/ \/_________/   \/_/     \_\/  
REM                                                                                             
REM
REM Script per il lancio di applicazioni CMEasy sotto Windows
REM Stefano Zucchi - 23-03-2016
SET PATHPRG=.\
cd %PATHPRG%
REM ---------- SETTO LE VARIABILI DI SISTEMA COME LA PATH E CLASSPATH  --------------
SET CMEasyPRG=cm_easy_recycler.exe
SET CMEasy_LOG=log_console\CMEasy.log
REM ---------- LANCIO DEL PROGRAMMA  --------------
DEL %CMEasy_LOG%.007
MOVE %CMEasy_LOG%.006 %CMEasy_LOG%.007
MOVE %CMEasy_LOG%.005 %CMEasy_LOG%.006
MOVE %CMEasy_LOG%.004 %CMEasy_LOG%.005
MOVE %CMEasy_LOG%.003 %CMEasy_LOG%.004
MOVE %CMEasy_LOG%.002 %CMEasy_LOG%.003
MOVE %CMEasy_LOG%.001 %CMEasy_LOG%.002
MOVE %CMEasy_LOG%     %CMEasy_LOG%.001
CLS
:INIZIO

ECHO LANCIO IL COMANDO : %CMEasyPRG%
%CMEasyPRG% 1>>%CMEasy_LOG% 2>>&1
IF ERRORLEVEL 1 GOTO INIZIO
exit

# Manuale di Configurazione: Modulo Integrazione Cassetto Elettronico

Questo manuale descrive la configurazione e il funzionamento del modulo di integrazione per i cassetti elettronici. Il sistema opera tramite un meccanismo di **File Watching** sulla directory configurata.

---

## Indice
1. [Connessione e Rete](#1-connessione-e-rete)
2. [Dati di Accesso e Handshake](#2-dati-di-accesso-e-handshake)
3. [Monitoraggio Directory](#3-monitoraggio-directory)
4. [Gestione File (Generici)](#4-gestione-file-generici)
5. [Specifiche Driver GLORY (output.txt)](#5-specifiche-driver-glory-outputtxt)
6. [Specifiche Driver CASHMATIC (error.txt)](#6-specifiche-driver-cashmatic-errortxt)
7. [Gestione File e Opzioni](#7-gestione-file-e-opzioni)
8. [Impostazioni Globali e Grafica](#8-impostazioni-globali-e-grafica)
9. [Criptazione (Solo Cashmatic)](#9-criptazione-solo-cashmatic)

---

## 1. Connessione e Rete
Definisce l'endpoint TCP/IP del cassetto elettronico.

| Parametro | Descrizione | Esempio |
| :--- | :--- | :--- |
| **address** | Indirizzo IP statico del cassetto. | `192.168.1.100` |
| **port** | Porta di comunicazione (default 8080). | `8080` |

---

## 2. Dati di Accesso e Handshake
Credenziali necessarie per l'autenticazione dell'applicativo presso il server del cassetto.

* **user_name**: Username per la connessione (es: `cassa`).
* **password**: Password per la connessione (es: `cassa`).
* **client_code**: **Obbligatorio**. Codice identificativo della cassa (es: `001`).
* **client_name**: Nome descrittivo del client.
* **client_user_code**: Codice operatore.
* **client_user_name**: Nome operatore.

---

## 3. Monitoraggio Directory
| Parametro | Descrizione | Esempio |
| :--- | :--- | :--- |
| **directory** | Percorso della cartella monitorata per lo scambio file. | `c:\test\test_watch` |

---

## 4. Gestione File (Generici)
File utilizzati da entrambi i driver per le operazioni principali.

* **input_file**: (`input.txt`) File per l'invio del comando di incasso.
* **cancel_file**: (`cancel.txt`) File per l'invio del comando di annullamento.
* **payout_file**: (`payout.txt`) File per comandi di erogazione (prelievo/resto).

---

## 5. Specifiche Driver GLORY (output.txt)
Quando il driver è impostato su `glory`, l'esito viene scritto nel file definito in `output_file`.

**Formato risposta:** `xx|yy|zz|ee`
* **xx**: Importo richiesto.
* **yy**: Importo inserito dal cliente.
* **zz**: Importo erogato.
* **ee**: Codice di stato/errore.

#### Tabella Codici (ee) - Glory:
| Codice | Descrizione |
| :--- | :--- |
| **0** | **Transazione conclusa correttamente.** |
| **1** | **Transazione annullata con successo.** |
| **9** | Errore annullamento: denaro inserito non restituibile. |
| **10** | Resto non erogabile: tagli insufficienti nel cassetto. |
| **11** | Dispositivo occupato (BUSY). |
| **12** | Problema nel payout o nell'erogazione del resto. |
| **100** | Errore generico di sistema. |

---

## 6. Specifiche Driver CASHMATIC (error.txt)
Il driver Cashmatic utilizza file dedicati per ogni fase. Gli errori vengono riportati in `error_file`.

**Formato risposta:** `xx|yy|zz|ee`

#### Tabella Codici (ee) - Cashmatic:
| Codice | Descrizione |
| :--- | :--- |
| **9** | Cassetto non riesce a restituire i soldi a fronte di un annullo. |
| **10** | Cassetto non riesce ad erogare il resto per tagli insufficienti. |
| **11** | Cassetto impegnato (BUSY). |
| **12** | Si è verificato un problema nel "payout" o erogazione. |
| **100** | Errore generico. |

---

## 7. Gestione File e Opzioni
Definisce il comportamento del sistema post-elaborazione.

| Parametro | Descrizione | Valore |
| :--- | :--- | :--- |
| **delete_input_file** | Elimina il file di input dopo la lettura. | `true` |
| **delete_cancel_file** | Elimina il file cancel dopo l'esecuzione. | `true` |

---

## 8. Impostazioni Globali e Grafica
| Parametro | Descrizione | Opzioni |
| :--- | :--- | :--- |
| **drawer** | Seleziona il driver hardware. | `glory` / `cashmatic` |
| **language** | Lingua dell'interfaccia utente. | `it` |
| **manage_graphics** | Abilita l'interfaccia grafica operativa. | `true` / `false` |

---

## 9. Criptazione (Solo Cashmatic)
Parametri per la sicurezza dei dati nei file di scambio (se abilitati).

* **crypto_enabled**: Attiva la cifratura dei file (`true`/`false`).
* **crypto_key**: Chiave di criptazione.
* **crypto_init_vector**: Vettore di inizializzazione.